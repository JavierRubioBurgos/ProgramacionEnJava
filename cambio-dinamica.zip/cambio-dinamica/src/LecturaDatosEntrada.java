import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class LecturaDatosEntrada {

	private int numeroMonedas;
	private int tabla[][];
	private int cantidadDevolver;
	private int monedas[];
	private Scanner scanner = new Scanner(System.in);

	public LecturaDatosEntrada() {
		leerConsola();
	}

	public LecturaDatosEntrada(String nombreFichero) throws Exception {
		leerFichero(nombreFichero);
	}
	
	private int pedirEntero(String mensaje) {
		int valor = 0;
		boolean error=false;
		do {
			error=false;
			System.out.println(mensaje);
			try {
				valor = Integer.parseInt(scanner.nextLine());
			}catch (Exception e) {
				System.out.println("Error, número incorrecto");
				error=true;
			}
			if(valor <= 0) {
				error=true;
				System.out.println("Error, tiene que ser un numero mayor que 0");
			}
		}while(error);
		
		return valor;
	}

	private void leerConsola() {
		// Pedir nº de monedas
		numeroMonedas=pedirEntero("Número de monedas:");
		// Pedir las n monedas
		monedas = new int[numeroMonedas];
		for(int i=0; i < monedas.length; i++) {
			monedas[i] = pedirEntero("Moneda: ");
		}
		// Pedir el cambio
		cantidadDevolver=pedirEntero("Cantidad a devolver");
		inicializarTabla();
	}

	private void leerFichero(String nombreFichero) throws Exception {
		File fichero = new File(nombreFichero);

		if (!fichero.exists()) {
			System.out.println("ERROR en lectura del fichero " + nombreFichero);
			System.out.println("Se solicitarán los datos por consola");
			leerConsola();
		} else {

				FileReader fReader = new FileReader(fichero);
				BufferedReader bReader = new BufferedReader(fReader);
				String lineaFichero;

				// Leemos tres linea del fichero
				for (int i = 1; i <= 3; i++) {
					lineaFichero = bReader.readLine();
					// 1º Linea nº monedas
					if (i == 1) {
						numeroMonedas = Integer.parseInt(lineaFichero);
						if (numeroMonedas <= 0) {
							throw new Exception("El numero de monedas tienes que ser mayor que 0");
						}
					} else if (i == 2) {
						// 2º Linea, valores de las monedas
						String[] valores = lineaFichero.split(" ");
						if (numeroMonedas != valores.length) {
							throw new Exception("No coinciden el número de monedas con las monedas del fichero");
						} else {
							// Creamos el vector con las monedas
							monedas = new int[numeroMonedas];
							// Inicializamos el vector de monedas
							for (int j = 0; j < numeroMonedas; j++) {
								monedas[j] = Integer.parseInt(valores[j]);
							}
						}
					} else {
						// 3º Linea, el cambio
						cantidadDevolver = Integer.parseInt(lineaFichero);
						inicializarTabla();
					}
				}
		}

	}

	private void inicializarTabla() {
		
		tabla= new int[numeroMonedas][cantidadDevolver+1];
		
		// Inicializamos la tabla
		 for (int i = 0; i < tabla.length; i++){
	            for (int j = 0; j < tabla[i].length; j++){
	            	tabla[i][j] = -1;
	            }
		 }
	}

	public void imprimirTabla(){
		// Primero fila el cambio
		System.out.print("\t");
		for(int i=0; i <= cantidadDevolver; i++) {
			 System.out.print(i+ "\t");
		}
		System.out.println();
		
        for (int i = 0; i < tabla.length; i++){
        	// La primera columna de la fila es el valor de la moneda
        	 System.out.print(monedas[i] + "\t");
            for (int j = 0; j < tabla[i].length; j++){
                System.out.print(tabla[i][j] + "\t");
            }
            System.out.println();
        }
    }

	public int getNumeroMonedas() {
		return numeroMonedas;
	}

	public int[][] getTabla() {
		return tabla;
	}

	public int getCantidadDevolver() {
		return cantidadDevolver;
	}

	public int[] getMonedas() {
		return monedas;
	}
	
	
	
}

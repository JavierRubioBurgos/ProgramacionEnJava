import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Algoritmo {

	private int numeroMonedas;
	private int tabla[][];
	private int cantidadDevolver;
	private int monedas[];
	
	private boolean mostrarTraza;
	private boolean existeFicheroSalida;
	private String nombreFicheroSalida = "";
	
	private int resultadoMonedas[];
	private FileWriter fWriter;
	private BufferedWriter bWriter;
	
	
	public Algoritmo(LecturaDatosEntrada entrada, boolean mostrarTraza, boolean existeFicheroSalida, String nombreFicheroSalida) {
		this.numeroMonedas = entrada.getNumeroMonedas();
		this.tabla = entrada.getTabla();
		this.cantidadDevolver = entrada.getCantidadDevolver();
		this.monedas = entrada.getMonedas();
		this.mostrarTraza = mostrarTraza;
		this.existeFicheroSalida=existeFicheroSalida;
		this.nombreFicheroSalida=nombreFicheroSalida;
		
		if(existeFicheroSalida) {
			try {
				File ficheroSalida = new File(nombreFicheroSalida);
				fWriter = new FileWriter(ficheroSalida);
				bWriter = new BufferedWriter(fWriter);
				
			}catch (Exception e) {
				System.out.println("Error al crear archivo de salida, se redirige la salida a la consola");
				existeFicheroSalida = false;
			}
		}
		
		this.resultadoMonedas = new int[monedas.length];
		// Iniciamos el algoritmo
		configurarTabla();
		seleccionarMonedas();
	}

	private void mostrarMensaje(String mensaje) {
		// Escribirmos la traza en el fichero
		if(existeFicheroSalida) {
			try {
				bWriter.write(mensaje+"\n");
			} catch (IOException e) {
				System.out.println("Error al escribir en el fichero de salida");
			}
		}else {
			// Escribimos la traza en la consola
			System.out.println(mensaje);
		}
	}
	
	
	public void configurarTabla() {

		// Inicializamos la primera columna
		for(int i=0; i < numeroMonedas; i ++) {
			tabla[i][0] = 0;
		}
		
		// configuración contenido de la tabla
		for (int j = 1; j <= cantidadDevolver; j++) {
			for (int i = 0; i < numeroMonedas; i++) {
				if(i == 0 && monedas[i] > j) {
					tabla[i][j] = -1;
					if(mostrarTraza) {
						mostrarMensaje("No existe cambio para la cantidad "+j+ " con la primera moneda "+monedas[i]);
					}
				}else {
					if(i==0) {
						tabla[i][j] = 1 + tabla[0][j-monedas[i]];
						if(mostrarTraza) {
							mostrarMensaje("Existe cambio para la cantidad "+j+ " con primera moneda "+monedas[i]+" cantidad de monedas "+tabla[i][j]);
						}
					}else{
						if(j < monedas[i]) {
							tabla[i][j] = tabla[i-1][j];
							if(mostrarTraza) {
								mostrarMensaje("La moneda "+monedas[i]+ " es mayor que el cambio "+j+", obtenemos cantidad de la moneda anterios "+tabla[i][j]);
							}
						}else {
							tabla[i][j] = Math.min(tabla[i-1][j], tabla[i][j-monedas[i]]+1);
							if(mostrarTraza) {
								mostrarMensaje("Con la moneda "+monedas[i]+ " se puede dar cambio para "+j+", la cantidad minima de monedas es "+tabla[i][j]);
							}
						}
					}
				}
			}
		}
	}
	
	public void seleccionarMonedas() {
		
		for(int i=0; i < resultadoMonedas.length; i++) {
			resultadoMonedas[i]=0;
		}
		int i = numeroMonedas-1;
		int j = cantidadDevolver;
		
		while(j>0) {
			if(i>0 && tabla[i][j] == tabla[i-1][j]) {
				i--;
			}else {
				resultadoMonedas[i] = resultadoMonedas[i] + 1;
				j = j - monedas[i];
			}
		}
		
		
	}

	public void escribirSolucion() {
		int numeroMonedas = 0;
		StringBuffer solucion = new StringBuffer();
	    for (int j = 0; j < resultadoMonedas.length; j++){
	    	if(resultadoMonedas[j] > 0) {
	    		numeroMonedas += resultadoMonedas[j];
	    		// En solución, añadimos tantas monedas como el valor del vector
	    		for(int k=1; k <= resultadoMonedas[j]; k++) {
	    			solucion.append(monedas[j]+" ");
	    		}
	    	}
	    }
	    
	    if(numeroMonedas == 0) {
	    	mostrarMensaje("No existe solución");
	    }else {
	    	mostrarMensaje( String.valueOf(numeroMonedas)  );
	    	mostrarMensaje(solucion.toString());
	    }
		
		
		 if(existeFicheroSalida) {
	        	try {
					bWriter.close();
					fWriter.close();
				} catch (IOException e) {
					System.out.println("Error al cerrar el fichero de salida");
				}
	        	
	        }
		
	}

}

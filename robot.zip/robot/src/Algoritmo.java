import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class Algoritmo {

	private boolean mostrarTraza;
	private boolean existeFicheroSalida;
	private String nombreFicheroSalida = "";
	private FileWriter fWriter;
	private BufferedWriter bWriter;
	
	public Algoritmo(boolean mostrarTraza, boolean existeFicheroSalida, String nombreFicheroSalida) {
		this.mostrarTraza = mostrarTraza;
		this.existeFicheroSalida=existeFicheroSalida;
		this.nombreFicheroSalida=nombreFicheroSalida;
		
		if(existeFicheroSalida) {
			try {
				File ficheroSalida = new File(nombreFicheroSalida);
				fWriter = new FileWriter(ficheroSalida);
				bWriter = new BufferedWriter(fWriter);
				
			}catch (Exception e) {
				System.out.println("Error al crear archivo de salida, se redirige la salida a la consola");
				existeFicheroSalida = false;
			}
		}
	}
	
	private void mostrarMensaje(String mensaje) {
		// Escribirmos la traza en el fichero
		if(existeFicheroSalida) {
			try {
				bWriter.write(mensaje+"\n");
			} catch (IOException e) {
				System.out.println("Error al escribir en el fichero de salida");
			}
		}else {
			// Escribimos la traza en la consola
			System.out.println(mensaje);
		}
	}
	
	
	public void iniciarBusqueda(char[][] edificio){
		Solucion solucionInicial = new Solucion(edificio);
		boolean resultado = buscaTornillo(solucionInicial, solucionInicial.getCasillaActual(),false);
		
		if(!resultado) {
			System.out.println("No se encontró un camino hasta el tornillo");
		}
		
	}
	
	public void mostrarSolucion(ArrayList<Casilla> solucion) {
		for(Casilla c : solucion) {
			System.out.println(c);
		}
		
	}
	
	public boolean buscaTornillo(Solucion solucion, Casilla casilla, boolean exito) {
		
		// Añadir casilla al vector de exploradas de nuestra solucion
		if(!solucion.casillaYaExplorada(casilla)) {
			
			solucion.addCasilla(casilla);

			
			if(solucion.finSolucion(casilla)) {
				// Encontrada solucion
				if(mostrarTraza) {
					mostrarMensaje("Encontrada solucion");
				}
				mostrarSolucion(solucion.getSolucion());
				exito = true;
				
			}else {
				// Creamos los hijos
				ArrayList<Solucion> hijo =  generarHijos(solucion);
				Iterator<Solucion> iterador = hijo.iterator();
				// Recorremos todos los hijos
				while(iterador.hasNext() && !exito) {
					Solucion sol = iterador.next();
					exito = buscaTornillo(sol,sol.getCasillaActual(),exito);
				}
			}
		}else {
			if(mostrarTraza) {
				mostrarMensaje("Casilla ya explorada: "+casilla);
			}
		}
		return exito;
		
	}
	
	public ArrayList<Solucion> generarHijos(Solucion solucion){
		
		ArrayList<Solucion> hijos = new ArrayList<Solucion>();
		
		Casilla casilla = solucion.getCasillaActual();
		char[][] edificio = solucion.getEdificio();
		// Solucion(char[][] edificio, boolean[][] exploradas, ArrayList<Casilla> solucion, Casilla casillaActual)
		
		// Comprobar si nos podemos mover hacia abajo
		if(casilla.getX() < edificio.length - 1   && edificio[casilla.getX()+1][casilla.getY()] != 'E') {
			Solucion hijoAbajo = new Solucion(edificio, solucion.getExploradas(), solucion.getSolucion(), new Casilla(casilla.getX()+1,casilla.getY()));
			hijos.add(hijoAbajo);
			if(mostrarTraza) {
				mostrarMensaje("Movimiento abajo: "+hijoAbajo.getCasillaActual());
			}
		}
		
		// Comprobar si nos podemos mover hacia arriba
		if(casilla.getX()>0 && edificio[casilla.getX()-1][casilla.getY()] != 'E') {
			Solucion hijoArriba = new Solucion(edificio, solucion.getExploradas(), solucion.getSolucion(), new Casilla(casilla.getX()-1,casilla.getY()));
			hijos.add(hijoArriba);
			if(mostrarTraza) {
				mostrarMensaje("Movimiento arriba: "+hijoArriba.getCasillaActual());
			}
		}
		
		// Comprobar si nos podemos mover hacia derecha
		if(casilla.getY() < edificio[0].length - 1   && edificio[casilla.getX()][casilla.getY()+1] != 'E') {
			Solucion hijoDerecha = new Solucion(edificio, solucion.getExploradas(), solucion.getSolucion(), new Casilla(casilla.getX(),casilla.getY()+1));
			hijos.add(hijoDerecha);
			if(mostrarTraza) {
				mostrarMensaje("Movimiento derecha: "+hijoDerecha.getCasillaActual());
			}
		}
		
		// Comprobar si nos podemos mover hacia izquierda
		if(casilla.getY() > 0   && edificio[casilla.getX()][casilla.getY()-1] != 'E') {
			Solucion hijoIzquierda = new Solucion(edificio, solucion.getExploradas(), solucion.getSolucion(), new Casilla(casilla.getX(),casilla.getY()-1));
			hijos.add(hijoIzquierda);
			if(mostrarTraza) {
				mostrarMensaje("Movimiento izquierda: "+hijoIzquierda.getCasillaActual());
			}
		}
		return hijos;
		
	}
}

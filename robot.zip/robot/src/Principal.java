
public class Principal {
	
	public static void mostrarAyuda() {
		System.out.println("SINTAXIS: robot [-t][-h] [fichero entrada]");
		System.out.println("\t-t Traza el algoritmo");
		System.out.println("\t-h Muestra esta ayuda");
		System.out.println("\t[fichero entrada] Nombre del fichero de entrada");
		System.out.println("\tfichero salida] Nombre del fichero de salida");
	}

	public static void main(String[] args) {
		
		LecturaDatosEntrada entrada = null;
		boolean mostrarTraza =false;
		boolean existeFicheroEntrada = false;
		String nombreFicheroEntrada="";
		boolean existeFicheroSalida = false;
		String nombreFicheroSalida="";
		
		for(int i=0; i < args.length ; i++) {
			String argumento = args[i].toLowerCase();
			
			switch(argumento) {
				case "-t":
					mostrarTraza = true;
					break;
				case "-h":
					mostrarAyuda();
					break;
				default:
					// Si se indica archivos el primero es el de entrada
					if(!existeFicheroEntrada) {
						existeFicheroEntrada=  true;
						nombreFicheroEntrada = argumento;
					}else {
						existeFicheroSalida = true;
						nombreFicheroSalida = argumento;
					}
			}
		}
		
		if(existeFicheroEntrada) {
			try {
			entrada = new LecturaDatosEntrada(nombreFicheroEntrada);
			} catch(Exception e) {
				System.out.println("ERROR en la lectura del fichero de entrada "+nombreFicheroEntrada);
				e.printStackTrace();
				System.exit(1);
			}
			
		}else {
			entrada = new LecturaDatosEntrada();
		}
		

		Algoritmo robot = new Algoritmo(mostrarTraza,existeFicheroSalida,nombreFicheroSalida);
		robot.iniciarBusqueda(entrada.getTablero());
		
	}

}

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class LecturaDatosEntrada {

	private char tablero[][];
	private Scanner scanner = new Scanner(System.in);
	int contadorTornillos=0;

	public LecturaDatosEntrada() {
		leerConsola();
	}

	public LecturaDatosEntrada(String nombreFichero) throws Exception {
		leerFichero(nombreFichero);
	}
	
	private int pedirEntero(String mensaje) {
		int valor = 0;
		boolean error=false;
		do {
			error=false;
			System.out.println(mensaje);
			try {
				valor = Integer.parseInt(scanner.nextLine());
			}catch (Exception e) {
				System.out.println("Error, número incorrecto");
				error=true;
			}
			if(valor <= 0) {
				error=true;
				System.out.println("Error, tiene que ser un numero mayor que 0");
			}
		}while(error);
		
		return valor;
	}

	private char pedirCasilla(String mensaje) {
		String valor = "";
		char letra =' ';
		boolean error=false;
		do {
			error=false;
			System.out.println(mensaje);
			try {
				valor = scanner.nextLine();
			}catch (Exception e) {
				System.out.println("Error, valor incorrecto");
				error=true;
			}
			if(valor.length() !=  1) {
				System.out.println("Error, solo puede ser un caracter");
				error=true;
			}
			// Solo valido L,E,T
			letra = valor.toUpperCase().charAt(0);
			if(letra!='L' && letra!='E' && letra!='T') {
				System.out.println("Error, solo puede ser el caracter L,E o T");
				error=true;
			}
			if(letra=='T' && contadorTornillos==1) {
				System.out.println("Error, solo puede tener un tornillo");
				error=true;
			}else if(letra=='T'){
				contadorTornillos++;
			}
		}while(error);
		
		return letra;
	}
	
	private void leerConsola() {
		
		int numFilas=pedirEntero("Número de filas:");
		int numColumnas=pedirEntero("Número de columnas:");
		
		// Inicializamos tablero
		tablero=new char[numFilas][numColumnas];
		
		for(int fila=0; fila < tablero.length; fila++) {
			for(int columna=0; columna < tablero[fila].length; columna++) {
				tablero[fila][columna]=pedirCasilla("Casilla["+fila+"]["+columna+"]: ");
			}
		}
	}

	private void leerFichero(String nombreFichero) throws Exception {
		File fichero = new File(nombreFichero);

		if (!fichero.exists()) {
			System.out.println("ERROR en lectura del fichero " + nombreFichero);
			System.out.println("Se solicitarán los datos por consola");
			leerConsola();
		} else {

				FileReader fReader = new FileReader(fichero);
				BufferedReader bReader = new BufferedReader(fReader);
				String lineaFichero;
				int numFilas;
				int numColumnas;

				// Leemos la fila
				lineaFichero = bReader.readLine();
				numFilas = Integer.parseInt(lineaFichero);
				// Leemos la columna
				lineaFichero = bReader.readLine();
				numColumnas = Integer.parseInt(lineaFichero);
				
				// Inicializamos el tablero
				tablero = new char [numFilas][numColumnas];
				
				// Leemos el tablero
				for (int fila = 0; fila < numFilas; fila++) {
					lineaFichero = bReader.readLine();
					String[] valoresFila = lineaFichero.split(" ");
					if(valoresFila.length != numColumnas) {
						throw new Exception("Numero de columnas de la fila "+fila+" incorrecto, "+valoresFila.length);
					}
					for(int columna=0; columna < numColumnas; columna++) {
						// Sólo puede tener una letra
						if(valoresFila[columna].length() !=  1) {
							throw new Exception("Valor incorrecto de la fila "+fila+" columna "+columna+" del tableo incorrecto");
						}
						// Solo valido L,E,T
						char letra = valoresFila[columna].toUpperCase().charAt(0);
						if(letra!='L' && letra!='E' && letra!='T') {
							throw new Exception("Valor incorrecto de la fila "+fila+" columna "+columna+" del tableo incorrecto");
						}
						
						if(letra=='T' && contadorTornillos==1) {
							throw new Exception("Hay más de un tornill en el edificio");
						}else if(letra=='T'){
							contadorTornillos++;
						}
						
						// Si el caracter es válido se almacena
						tablero[fila][columna]=letra;
					}
				}
		}

	}



	public void imprimirTabla(){
		// Primero fila el cambio
		for(int fila=0; fila < tablero.length; fila++) {
			for(int columna=0; columna < tablero[fila].length; columna++) {
				System.out.print(tablero[fila][columna]+" ");
			}
			System.out.println();
		}
    }

	public char[][] getTablero() {
		return tablero;
	}
	
	


}

import java.util.ArrayList;

public class Solucion {

	private char edificio[][];
	private boolean exploradas[][];
	private ArrayList<Casilla> solucion;
	private Casilla casillaActual;
	
	
	/**
	 * Constructor para la solución inicial
	 * @param edificio
	 */
	public Solucion(char[][] edificio) {
		this.edificio = edificio;
		this.solucion = new ArrayList<Casilla>();
		this.casillaActual=new Casilla(0,0);
		this.exploradas=new boolean[edificio.length][edificio[0].length];
	}
	
	
	public Solucion(char[][] edificio, boolean[][] exploradas, ArrayList<Casilla> solucion, Casilla casillaActual) {
		this.edificio = edificio;
		this.exploradas = exploradas;
		this.solucion = solucion;
		this.casillaActual=casillaActual;
	}
	
	public void addCasilla(Casilla c) {
		this.exploradas[c.getX()][c.getY()] = true;
		this.solucion.add(0,c);
	}
	
	public boolean finSolucion(Casilla casilla) {
		return edificio[casilla.getX()][casilla.getY()] == 'T';
	}

	public Casilla getCasillaActual() {
		return casillaActual;
	}

	public void setCasillaActual(Casilla casillaActual) {
		this.casillaActual = casillaActual;
	}

	public char[][] getEdificio() {
		return edificio;
	}

	public void setEdificio(char[][] edificio) {
		this.edificio = edificio;
	}

	public boolean[][] getExploradas() {
		return exploradas;
	}

	public void setExploradas(boolean[][] exploradas) {
		this.exploradas = exploradas;
	}

	public ArrayList<Casilla> getSolucion() {
		return solucion;
	}

	public void setSolucion(ArrayList<Casilla> solucion) {
		this.solucion = solucion;
	}
	
	
	public boolean casillaYaExplorada(Casilla casilla) {
		return exploradas[casilla.getX()][casilla.getY()];
	}
	
	public void addCasillaExplorada(Casilla casilla) {
		exploradas[casilla.getX()][casilla.getY()] = true;
	}
		
}
